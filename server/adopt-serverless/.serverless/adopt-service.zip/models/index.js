const User = require('./User');
const Pet = require('./Pet');


module.exports = { User, Pet };
